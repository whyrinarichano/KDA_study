import requests
import json
import os

# API_URL
__API_URL = 'https://openapi.dacon.io/submission'

def post_submission_file(file_path, token, cpt_id, team_name, memo=''):
  '''
    Post Submission File to DACON API
    [file_path]: {
      description: Path of a submission file
      required: True
    },

    [token]: {
      description: Token issued by dacon
      required: True
    },

    [cpt_id]: {
      description: Competition ID
      required: True
    },

    [team_name]: {
      description: Team name(you can check it from DACON Web Site in Competition/Team Page, https://dacon.io)
      required: True
    },

    [memo]: {
      description: Memo for the Submission file
      required: False
    },
  '''
  try:
    # Find submission file
    files={
      'file':(open(file_path, 'rb'))
    }

    # 100MB 이상의 데이터는 용량 제한
    if os.path.getsize(file_path) > 104857601:
      return {'isSubmitted':False, 'detail': 'Too large to upload. 용량이 너무 큽니다!'}

    # Set Data & Header
    data = { 'cpt_id': cpt_id, 'team_name': team_name,'file_name': os.path.basename(files['file'].name), 'memo':memo, 'api_token': token, 'api_version': 2.0 }
    # Send POST
    response = requests.post(__API_URL, data=data, files=files)


    # Print Response of API
    # # print(res.request.headers)
    # # print('\n')
    # # print(res.request.body)
    result = decode_submission_response(response)
    print(result)
    return response
  except Exception as e:
    print('exception occurs. 예외가 발생했습니다', e)


def decode_submission_response(response):
  # print(response.json())
  error_type = {
    1: "csv file header error. csv 파일의 헤더 오류",
    2: "data parsing error. 데이터 파싱 오류",
    3: "number of row error. row 개수 오류",
    4: "other submission value error. 기타 제출값 오류",
    21: "data type error. 데이터 타입 오류",
    901: "csv file's header doesn't match. csv 파일의 헤더가 올바르지 않습니다",
    902: "error occurs in data parsing. 데이터 파싱간 에러가 발생했습니다",
    903: "number of row doesn't match. row 개수가 맞지 않습니다",
    904: "submission value occurs error. 기타 제출값에 오류가 발생했습니다",
    9021: "data must not have Character. 데이터에 문자가 들어갈 수 없습니다.",
  }
  message = response.json()['message']
  if message == 'ok':
    return {'isSubmitted':True, 'detail': 'Success'}
  elif message == 'over_max_count':
    return {'isSubmitted':False, 'detail': 'Over max submission count of Competition. 대회 기간 중 제출 가능한 최대 횟수가 초과 되었습니다'}
  elif message == 'day_max_count':
    return {'isSubmitted':False, 'detail': 'Over max submission count of Daily. 일일 제출 가능한 최대 횟수가 초과 되었습니다.'}
  elif message == 'wrong':
    return {'isSubmitted':False, 'detail': error_type[response.json()['data']]}

if __name__ == '__main__':
  import argparse

  # get arguments
  parser = argparse.ArgumentParser(description='DACON Competition Submission API')
  parser.add_argument('--file_path', required=True, help="Path of a submission file")
  parser.add_argument('--token', required=True, help="Token issued by dacon")
  parser.add_argument('--cpt_id', required=True, help="Competition ID")
  parser.add_argument('--team_name', required=True, help="Team name(you can check it from DACON Web Site in Competition/Team Page)")
  parser.add_argument('--memo', required=False, default='', help="Memo for the Submission file[optional]")
  args = parser.parse_args()

  # print input arguments
  print('file_path: ', args.file_path)
  print('token: ', args.token)
  print('cpt_id: ', args.cpt_id)
  print('team_name: ', args.team_name)
  print('memo: ', args.memo)

  response = post_submission_file(__API_URL, args.file_path, args.token, args.cpt_id, args.team_name, args.memo)
  result = decode_submission_response(response)
   # Print Response of API
  print(result)